import HeaderOne from '@/layouts/headers/HeaderOne';
import React from 'react';

const HomeOne = () => {
  return (
    <>
      <HeaderOne />

      
    </>
  );
};

export default HomeOne;